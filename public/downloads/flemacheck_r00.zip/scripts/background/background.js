// scripts/background/background.js

import { fetchRakumaByTab, fetchYFleaByTab, fetchYahooAuctionByTab } from '../modules/tabRunner.js';
import { saveItemsToDb } from '../modules/dbClient.js';

// 拡張機能アイコン（Actionボタン）クリックでサイドパネルを開く設定
chrome.sidePanel
  .setPanelBehavior({ openPanelOnActionClick: true })
  .catch((error) => console.error(error));

// タブのURLが更新された時の監視 (メルカリでのみパネルを有効化)
chrome.tabs.onUpdated.addListener(async (tabId, info, tab) => {
    const targetUrl = info.url || tab.url;

    if (targetUrl) {
        try {
            const url = new URL(targetUrl);
            const isMercari = url.hostname.endsWith('mercari.com') || url.hostname.endsWith('mercari.jp');
            
            if (isMercari) {
                // メルカリのタブに対してのみ、サイドパネルのHTMLを割り当てて有効化
                await chrome.sidePanel.setOptions({
                    tabId: tabId,
                    path: 'scripts/sidepanel/sidepanel.html',
                    enabled: true
                });
                return;
            }
        } catch (e) {}
    }
    
    // URLが読み取れない、またはメルカリ以外の場合はパネルを無効化
    await chrome.sidePanel.setOptions({
        tabId: tabId,
        enabled: false
    }).catch(() => {});
});

/**
 * 閲覧中のタブURLから検索キーワードを抽出する関数
 */
function extractKeywordFromTabUrl(urlStr) {
    if (!urlStr) return '';
    try {
        const url = new URL(urlStr);
        const keyword = url.searchParams.get('keyword') || url.searchParams.get('query') || '';
        return decodeURIComponent(keyword).trim();
    } catch (e) {
        return '';
    }
}

/**
 * 生ステータスを安全に拾い出す関数
 */
function extractRawStatus(item) {
    if (!item) return 'on_sale';

    if (item.itemStatus) return item.itemStatus;
    if (item.openStatus) return item.openStatus;

    const rawData = item.raw_json || item.rawJson;
    if (rawData) {
        try {
            const parsed = typeof rawData === 'string' ? JSON.parse(rawData) : rawData;
            if (parsed?.itemStatus) return parsed.itemStatus;
            if (parsed?.openStatus) return parsed.openStatus;
        } catch (e) {}
    }

    return item.status || 'on_sale';
}

/**
 * ステータスをDB標準フォーマットに正規化する関数
 */
function normalizeStatus(rawStatus) {
    if (!rawStatus) return 'on_sale';

    const statusStr = String(rawStatus).toUpperCase();

    if (['ITEM_STATUS_SOLD_OUT', 'ITEM_STATUS_TRADING', 'SOLD', 'SOLD_OUT', 'CLOSED'].includes(statusStr)) {
        return 'sold_out';
    }

    if (['ITEM_STATUS_ON_SALE', 'ON_SALE', 'OPEN'].includes(statusStr)) {
        return 'on_sale';
    }

    if (['ITEM_STATUS_INACTIVE', 'ITEM_STATUS_CANCELLED', 'ENDED'].includes(statusStr)) {
        return 'ended';
    }

    if (['on_sale', 'sold_out', 'ended'].includes(rawStatus)) {
        return rawStatus;
    }

    return 'on_sale';
}

/**
 * 生データから出品日時(start_time)をISO 8601文字列として抽出・正規化する関数
 */
function extractStartTime(site, item) {
    if (!item) return null;

    if (item.start_time) return item.start_time;
    if (item.startTime) return item.startTime;

    const raw = item.raw_json || item.rawJson || item;
    const parsedRaw = typeof raw === 'string' ? (() => { try { return JSON.parse(raw); } catch(e) { return {}; } })() : raw;

    try {
        if (site === 'mercari') {
            const created = item.created || parsedRaw?.created;
            if (created) {
                const ts = parseInt(created, 10);
                if (!isNaN(ts)) return new Date(ts * 1000).toISOString();
            }
        } else if (site === 'yflea') {
            const openTime = item.openTime || parsedRaw?.openTime || parsedRaw?.raw_json?.openTime;
            if (openTime) {
                return new Date(openTime).toISOString();
            }
        } else if (site === 'yahoo_auction') {
            const stm = item.stm || parsedRaw?.stm || parsedRaw?.raw_json?.stm;
            if (stm) {
                const ts = parseInt(stm, 10);
                if (!isNaN(ts)) return new Date(ts * 1000).toISOString();
            }
        } else if (site === 'rakuma') {
            const created = item.created_at || item.created || parsedRaw?.created_at || parsedRaw?.created;
            if (created) {
                return new Date(created).toISOString();
            }
        }
    } catch (e) {
        console.error(`[${site}] start_time 抽出エラー:`, e);
    }

    return null;
}

/**
 * 生データからSold/終了日時(last_status_changed_at)をISO 8601文字列として抽出・正規化する関数
 */
function extractLastStatusChangedAt(site, item, normalizedStatus) {
    if (!item) return null;

    if (item.last_status_changed_at) return item.last_status_changed_at;
    if (item.lastStatusChangedAt) return item.lastStatusChangedAt;

    const raw = item.raw_json || item.rawJson || item;
    const parsedRaw = typeof raw === 'string' ? (() => { try { return JSON.parse(raw); } catch(e) { return {}; } })() : raw;

    try {
        if (normalizedStatus === 'sold_out' || normalizedStatus === 'ended') {
            if (site === 'mercari') {
                const updated = item.updated || parsedRaw?.updated;
                if (updated) {
                    const ts = parseInt(updated, 10);
                    if (!isNaN(ts)) return new Date(ts * 1000).toISOString();
                }
            } else if (site === 'yflea') {
                const endTime = item.endTime || parsedRaw?.endTime || parsedRaw?.raw_json?.endTime;
                if (endTime) {
                    return new Date(endTime).toISOString();
                }
            } else if (site === 'yahoo_auction') {
                const etm = item.etm || parsedRaw?.etm || parsedRaw?.raw_json?.etm;
                if (etm) {
                    const ts = parseInt(etm, 10);
                    if (!isNaN(ts)) return new Date(ts * 1000).toISOString();
                }
            }
        }
    } catch (e) {
        console.error(`[${site}] last_status_changed_at 抽出エラー:`, e);
    }

    return null;
}

/**
 * ノイズ（関連商品）を除外するタイトルマッチング関数
 */
function isTitleMatching(title, keyword) {
    if (!keyword || !title) return true;

    const normTitle = title.toLowerCase();
    const normKeyword = keyword.toLowerCase();

    const cleanKeyword = normKeyword.replace(/[―ー\-/\_／―・!！?？:：,，.．\(\)（）\[\]【】]/g, ' ');
    const words = cleanKeyword.split(/\s+/).filter(w => w.length >= 2);

    if (words.length === 0) return true;

    const englishWords = words.filter(w => /^[a-z0-9]+$/.test(w));
    const hasAllEnglishWords = englishWords.every(w => normTitle.includes(w));

    if (!hasAllEnglishWords) return false;

    const otherWords = words.filter(w => !/^[a-z0-9]+$/.test(w));
    if (otherWords.length > 0) {
        const matchedCount = otherWords.filter(w => normTitle.includes(w)).length;
        const requiredCount = otherWords.length === 1 ? 1 : Math.ceil(otherWords.length * 0.5);
        if (matchedCount < requiredCount) return false;
    }

    return true;
}

/**
 * 画像URL抽出関数
 */
function extractImageUrl(item) {
    if (!item) return null;

    let url = '';

    if (typeof item.image === 'string') url = item.image;
    else if (item.image && typeof item.image.url === 'string') url = item.image.url;
    else if (item.image_url) url = item.image_url;
    else if (item.imageUrl) url = item.imageUrl;
    else if (item.thumbnailUrl) url = item.thumbnailUrl;
    else if (item.thumbnail) url = item.thumbnail;
    else if (item.img_url) url = item.img_url;
    else if (item.data_src) url = item.data_src;
    else if (item.data_original) url = item.data_original;

    if (!url && Array.isArray(item.images) && item.images.length > 0) {
        const first = item.images[0];
        url = typeof first === 'string' ? first : (first.url || first.image_url || '');
    }
    if (!url && Array.isArray(item.thumbnails) && item.thumbnails.length > 0) {
        const first = item.thumbnails[0];
        url = typeof first === 'string' ? first : (first.url || '');
    }
    if (!url && Array.isArray(item.photos) && item.photos.length > 0) {
        const first = item.photos[0];
        url = typeof first === 'string' ? first : (first.url || first.name || '');
    }

    if (typeof url !== 'string') return null;

    if (url.startsWith('data:image/') || url.includes('loading') || url.includes('placeholder') || url.includes('blank.gif')) {
        if (item['data-original']) url = item['data-original'];
        else if (item['data-src']) url = item['data-src'];
        else return null;
    }

    if (url.startsWith('//')) {
        url = 'https:' + url;
    }

    return url || null;
}

/**
 * 各サイトの商品IDから完全な絶対URLを生成・補填するヘルパー関数
 */
function buildFullUrl(site, item, rawUrl, itemId) {
    let url = String(rawUrl || '').trim();

    if (url.startsWith('//')) {
        return 'https:' + url;
    }
    if (url.startsWith('http://') || url.startsWith('https://')) {
        return url;
    }

    if (!itemId && !url) return url;

    switch (site) {
        case 'mercari': {
            if (url.startsWith('/')) {
                return `https://jp.mercari.com${url}`;
            }

            const itemType = String(item.itemType || item.item_type || '').toUpperCase();
            const isShops = 
                itemType.includes('SHOPS') || 
                Boolean(item.shop) || 
                Boolean(item.shopId) || 
                Boolean(item.shop_id) ||
                Boolean(item.isShops);

            if (isShops) {
                return `https://jp.mercari.com/shops/product/${itemId}`;
            }
            return `https://jp.mercari.com/item/${itemId}`;
        }
        case 'rakuma':
            return url.startsWith('/') ? `https://item.fril.jp${url}` : `https://item.fril.jp/${itemId}`;
        case 'yflea':
            return url.startsWith('/') ? `https://paypayfleamarket.yahoo.co.jp${url}` : `https://paypayfleamarket.yahoo.co.jp/item/${itemId}`;
        case 'yahoo_auction':
            return url.startsWith('/') ? `https://page.auctions.yahoo.co.jp${url}` : `https://page.auctions.yahoo.co.jp/jp/auction/${itemId}`;
        default:
            return url;
    }
}

/**
 * 取得データを DB 用のスキーマ形式に正規化する関数
 */
function formatItemsForDb(items, defaultSite, keyword) {
    const cleanKeyword = (keyword || '').trim();

    return items
        .filter(item => {
            const site = item.site || defaultSite;
            if (site === 'rakuma') {
                const title = item.title || item.name || '';
                return isTitleMatching(title, cleanKeyword);
            }
            return true;
        })
        .map(item => {
            const site = item.site || defaultSite;
            const itemId = String(item.item_id || item.itemId || item.id || '');
            const fullUrl = buildFullUrl(site, item, item.url, itemId);
            const status = normalizeStatus(extractRawStatus(item));

            return {
                site: site,
                item_id: itemId,
                keyword: cleanKeyword || item.keyword || '',
                title: item.title || item.name || '',
                price: Number(item.price) || 0,
                buyout_price: item.buyout_price ?? item.buyoutPrice ?? null,
                url: fullUrl,
                image_url: extractImageUrl(item),
                is_shipping_included: (item.is_shipping_included ?? item.isShippingIncluded ?? true) ? 1 : 0,
                status: status,
                condition_id: item.condition_id ?? item.conditionId ?? null,
                bids_count: item.bids_count ?? item.bidsCount ?? 0,
                start_time: extractStartTime(site, item),
                end_time: item.end_time ?? item.endTime ?? null,
                last_status_changed_at: extractLastStatusChangedAt(site, item, status),
                seller_id: item.seller_id ? String(item.seller_id) : (item.sellerId ? String(item.sellerId) : null),
                category_id: item.category_id ? String(item.category_id) : (item.categoryId ? String(item.categoryId) : null),
                brand_name: item.brand_name || item.brandName || null,
                likes_count: item.likes_count ?? item.likesCount ?? 0,
                raw_json: JSON.stringify(item)
            };
        });
}

/**
 * UIへ通知を送信する関数
 */
async function notifyDbUpdated(keyword) {
    if (!keyword) return;

    try {
        await chrome.storage.local.set({ lastKeyword: keyword });
    } catch (e) {
        console.error('Storage set error:', e);
    }

    chrome.runtime.sendMessage({
        action: 'DB_UPDATED',
        keyword: keyword
    }).catch(() => {});
}

/**
 * 他3サイト並列検索
 */
async function triggerAllFleaMarketSearches(keyword) {
    console.log(`【全フリマ検索開始】キーワード: "${keyword}"`);

    Promise.allSettled([
        fetchRakumaByTab(keyword),
        fetchYFleaByTab(keyword),
        fetchYahooAuctionByTab(keyword)
    ]).then(async ([rakumaRes, yfleaRes, yahooAucRes]) => {
        console.group(`【Background】全フリマデータ取得完了 ("${keyword}")`);
        
        const rakumaItems = rakumaRes.status === 'fulfilled' ? rakumaRes.value : [];
        const yfleaItems = yfleaRes.status === 'fulfilled' ? yfleaRes.value : [];
        const yahooAucItems = yahooAucRes.status === 'fulfilled' ? yahooAucRes.value : [];

        console.log(`ラクマ: ${rakumaItems.length} 件`, rakumaItems);
        console.log(`Yフリマ: ${yfleaItems.length} 件`, yfleaItems);
        console.log(`ヤフオク: ${yahooAucItems.length} 件`, yahooAucItems);
        console.groupEnd();

        const allFetchedItems = [
            ...formatItemsForDb(rakumaItems, 'rakuma', keyword),
            ...formatItemsForDb(yfleaItems, 'yflea', keyword),
            ...formatItemsForDb(yahooAucItems, 'yahoo_auction', keyword)
        ];

        if (allFetchedItems.length > 0) {
            const result = await saveItemsToDb(allFetchedItems);
            if (result.success) {
                console.log(`✅ 【DB保存完了】他3サイトのデータ ${result.count} 件をUPSERT保存しました。`);
                notifyDbUpdated(keyword);
            }
        }
    });
}

// ==========================================
// メッセージリスナー (一覧検索データの受信)
// ==========================================
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    
    // 一覧検索からのデータ受信処理
    if (request.action === 'PROCESS_MARKET_DATA') {
        const payload = request.data;

        if (payload.status === 429 || payload.isRateLimited) {
            console.error(`【警告】429 Rate Limit を検知しました（対象: ${payload.site}）。`);
            return;
        }

        if (payload.items && payload.items.length > 0) {
            const tabUrl = sender.tab ? sender.tab.url : '';
            const keyword = extractKeywordFromTabUrl(tabUrl);

            const formattedMercariItems = formatItemsForDb(payload.items, payload.site || 'mercari', keyword);
            saveItemsToDb(formattedMercariItems).then((res) => {
                if (res?.success) {
                    console.log(`✅ 【DB保存完了】${payload.site || 'mercari'} データ ${res.count} 件をUPSERT保存しました。`);
                    if (keyword) notifyDbUpdated(keyword);
                }
            });

            if (keyword) {
                triggerAllFleaMarketSearches(keyword);
            }
        }
        return true;
    }
});