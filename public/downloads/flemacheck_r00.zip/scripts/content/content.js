// ==========================================
// 共通ヘルパー: DOM要素から本物の画像URLを抽出する関数
// ==========================================
function getValidImageUrl(imgEl) {
    if (!imgEl) return '';
    const srcCandidates = [
        imgEl.getAttribute('data-original'),
        imgEl.getAttribute('data-src'),
        imgEl.getAttribute('data-url'),
        imgEl.src
    ];

    for (let url of srcCandidates) {
        if (!url || typeof url !== 'string') continue;
        
        if (
            url.startsWith('data:image/') || 
            url.includes('dummy') || 
            url.includes('placeholder') || 
            url.includes('blank.gif') || 
            url.includes('loading')
        ) {
            continue;
        }

        if (url.startsWith('//')) {
            url = 'https:' + url;
        }
        return url;
    }
    return '';
}

// ==========================================
// 1. inject.js からの受信 (メルカリ用)
// ==========================================
window.addEventListener("message", (event) => {
    if (event.source === window && event.data && event.data.source === 'FLEA_MARKET_HOOK') {
        if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id) {
            try {
                chrome.runtime.sendMessage({
                    action: 'PROCESS_MARKET_DATA',
                    data: event.data.payload
                }).catch(() => {});
            } catch (e) {
                // コンテキスト無効化エラーを無視
            }
        }
    }
});

// ==========================================
// 2. ラクマ 抽出処理 (裏タブ用)
// ==========================================
if (window.location.hostname.includes('fril.jp')) {
    let checkCount = 0;
    const interval = setInterval(() => {
        checkCount++;
        const linkElements = document.querySelectorAll('a.link_search_image[href*="item.fril.jp"]');

        if (linkElements.length > 0 || checkCount >= 10) {
            clearInterval(interval);
            const items = [];
            const processedIds = new Set();

            linkElements.forEach(linkEl => {
                const href = linkEl.href;
                const rawOnClick = linkEl.getAttribute('onclick') || '';
                const onclickText = rawOnClick.replace(/&quot;/g, '"');
                
                const extractData = (key) => {
                    const reg = new RegExp(`"${key}"\\s*:\\s*"(.*?)"|"${key}"\\s*:\\s*([0-9.]+|null)`);
                    const match = onclickText.match(reg);
                    if (!match) return null;
                    return match[1] !== undefined ? match[1] : (match[2] === 'null' ? null : match[2]);
                };

                const itemId = extractData('item_id') || href.split('/').pop().split('?')[0];
                const itemName = extractData('item_name') || (linkEl.title ? linkEl.title.split(' 商品詳細ページ')[0] : '');
                const rawPrice = extractData('price');
                const price = rawPrice ? parseInt(rawPrice, 10) : 0;

                if (!itemId || processedIds.has(itemId)) return;
                processedIds.add(itemId);

                const itemContainer = linkEl.closest('.item') || linkEl.parentElement;
                let imageUrl = '';
                let isSold = false;
                let isShippingIncluded = true;

                if (itemContainer) {
                    const imgEl = itemContainer.querySelector('img');
                    if (imgEl) imageUrl = getValidImageUrl(imgEl);
                    
                    const containerText = itemContainer.textContent || '';
                    isSold = containerText.includes('SOLD') || !!itemContainer.querySelector('[class*="sold"]');
                    if (containerText.includes('着払い')) isShippingIncluded = false;
                }

                // 出品日時パラメータがあれば抽出
                const rawCreatedAt = extractData('created_at') || extractData('created');
                let createdAtIso = null;
                if (rawCreatedAt) {
                    if (!isNaN(rawCreatedAt)) {
                        createdAtIso = new Date(parseInt(rawCreatedAt, 10) * 1000).toISOString();
                    } else {
                        createdAtIso = new Date(rawCreatedAt).toISOString();
                    }
                }

                if (itemId && price > 0) {
                    items.push({
                        site: 'rakuma',
                        item_id: itemId,
                        title: itemName,
                        price: price,
                        seller_user_id: extractData('seller_user_id'),
                        category_id: extractData('category_id'),
                        brand_id: extractData('brand_id'),
                        brand_name: extractData('brand_name'),
                        url: href,
                        image_url: imageUrl,
                        is_shipping_included: isShippingIncluded,
                        status: isSold ? 'sold_out' : 'on_sale',
                        created_at: createdAtIso
                    });
                }
            });

            if (chrome.runtime?.id) {
                chrome.runtime.sendMessage({ action: 'RAKUMA_DATA_CAPTURED', data: items }).catch(() => {});
            }
        }
    }, 500);
}

// ==========================================
// 3. Yフリマ (PayPayフリマ) 抽出処理
// ==========================================
if (window.location.hostname.includes('paypayfleamarket.yahoo.co.jp')) {
    let checkCount = 0;
    const interval = setInterval(() => {
        checkCount++;
        let items = [];

        const nextDataScript = document.getElementById('__NEXT_DATA__');
        if (nextDataScript && nextDataScript.textContent) {
            try {
                const nextData = JSON.parse(nextDataScript.textContent);
                items = extractYFleaItemsFromNextData(nextData);
            } catch (e) {
                console.warn('【Content Script】Yフリマ __NEXT_DATA__ パース失敗:', e);
            }
        }

        if (items.length === 0) {
            const linkElements = document.querySelectorAll('a[href*="/item/"]');
            if (linkElements.length > 0) {
                const processedIds = new Set();
                linkElements.forEach(linkEl => {
                    const href = linkEl.href;
                    const clParams = linkEl.getAttribute('data-cl-params') || '';

                    const itemIdMatch = clParams.match(/rcconid:([a-z0-9]+)/i);
                    const priceMatch = clParams.match(/price:([0-9]+)/) || clParams.match(/p=([0-9]+)/);
                    const sellerMatch = clParams.match(/sellerid:([a-z0-9]+)/i);
                    const catMatch = clParams.match(/catid:([0-9]+)/);
                    
                    // stm=数字 または st:数字 に対応
                    const startTimeMatch = clParams.match(/stm[=:]?([0-9]+)/) || clParams.match(/st:([0-9]+)/);
                    const endTimeMatch = clParams.match(/etm[=:]?([0-9]+)/) || clParams.match(/end:([0-9]+)/);

                    const itemId = itemIdMatch ? itemIdMatch[1] : href.split('/item/')[1]?.split('?')[0];
                    const price = priceMatch ? parseInt(priceMatch[1], 10) : 0;

                    if (!itemId || processedIds.has(itemId)) return;
                    processedIds.add(itemId);

                    const imgEl = linkEl.querySelector('img') || (linkEl.parentElement ? linkEl.parentElement.querySelector('img') : null);
                    const title = imgEl && imgEl.alt ? imgEl.alt : '';
                    const imageUrl = getValidImageUrl(imgEl);

                    const stmSec = startTimeMatch ? parseInt(startTimeMatch[1], 10) : null;
                    const etmSec = endTimeMatch ? parseInt(endTimeMatch[1], 10) : null;

                    if (itemId && price > 0) {
                        items.push({
                            site: 'yflea',
                            item_id: itemId,
                            title: title,
                            price: price,
                            seller_user_id: sellerMatch ? sellerMatch[1] : null,
                            category_id: catMatch ? catMatch[1] : null,
                            url: href,
                            image_url: imageUrl,
                            is_shipping_included: true,
                            status: 'on_sale',
                            openTime: stmSec ? new Date(stmSec * 1000).toISOString() : null,
                            endTime: etmSec ? new Date(etmSec * 1000).toISOString() : null
                        });
                    }
                });
            }
        }

        if (items.length > 0 || checkCount >= 10) {
            clearInterval(interval);
            if (chrome.runtime?.id) {
                chrome.runtime.sendMessage({ action: 'YFLEA_DATA_CAPTURED', data: items }).catch(() => {});
            }
        }
    }, 500);
}

/**
 * __NEXT_DATA__ JSONオブジェクト内から商品配列を探索・抽出するヘルパー
 */
function extractYFleaItemsFromNextData(data) {
    const items = [];

    function search(obj) {
        if (!obj || typeof obj !== 'object') return;

        if (Array.isArray(obj)) {
            for (const element of obj) {
                if (element && typeof element === 'object') {
                    const id = element.id || element.itemId || element.item_id;
                    const price = element.price;
                    const title = element.title || element.name || element.itemName;

                    if (id && price !== undefined && title) {
                        let imgUrl = element.thumbnailImageUrl || element.imageUrl || element.thumbnailUrl || element.thumbnail || '';
                        
                        if (!imgUrl && Array.isArray(element.images) && element.images.length > 0) {
                            const firstImg = element.images[0];
                            imgUrl = typeof firstImg === 'string' ? firstImg : (firstImg.url || firstImg.imageUrl || firstImg.src || '');
                        } else if (!imgUrl && Array.isArray(element.media) && element.media.length > 0) {
                            imgUrl = element.media[0]?.content?.url || element.media[0]?.url || '';
                        } else if (!imgUrl && element.image && typeof element.image === 'object') {
                            imgUrl = element.image.url || element.image.src || '';
                        } else if (!imgUrl && typeof element.image === 'string') {
                            imgUrl = element.image;
                        }

                        if (typeof imgUrl === 'string' && imgUrl.startsWith('//')) {
                            imgUrl = 'https:' + imgUrl;
                        }

                        items.push({
                            site: 'yflea',
                            item_id: String(id),
                            title: String(title).trim(),
                            price: typeof price === 'number' ? price : parseInt(String(price).replace(/[^0-9]/g, ''), 10) || 0,
                            seller_user_id: element.sellerId || element.seller_id || (element.seller ? element.seller.id : null),
                            category_id: element.categoryId || element.category_id || null,
                            url: `https://paypayfleamarket.yahoo.co.jp/item/${id}`,
                            image_url: imgUrl || null,
                            is_shipping_included: true,
                            status: element.itemStatus === 'SOLD' ? 'sold_out' : 'on_sale',
                            openTime: element.openTime || null,
                            endTime: element.endTime || null,
                            raw_json: element
                        });
                    } else {
                        search(element);
                    }
                }
            }
            return;
        }

        for (const key of Object.keys(obj)) {
            if (obj[key] && typeof obj[key] === 'object') {
                search(obj[key]);
            }
        }
    }

    search(data);

    const uniqueMap = new Map();
    items.forEach(item => {
        if (item.item_id && item.price > 0 && !uniqueMap.has(item.item_id)) {
            uniqueMap.set(item.item_id, item);
        }
    });

    return Array.from(uniqueMap.values());
}

// ==========================================
// 4. ヤフオク 抽出処理
// ==========================================
if (window.location.hostname.includes('auctions.yahoo.co.jp')) {
    let checkCount = 0;
    const interval = setInterval(() => {
        checkCount++;
        const linkElements = document.querySelectorAll('a[href*="/auction/"][data-cl-params]');

        if (linkElements.length > 0 || checkCount >= 10) {
            clearInterval(interval);
            const items = [];
            const processedIds = new Set();

            linkElements.forEach(linkEl => {
                const href = linkEl.href;
                const clParams = linkEl.getAttribute('data-cl-params') || '';

                const cidMatch = clParams.match(/cid:([a-z0-9]+)/i);
                const priceMatch = clParams.match(/p=([0-9]+)/) || clParams.match(/price:([0-9]+)/);
                const catMatch = clParams.match(/catid:([0-9]+)/);

                // ★ Fact対応: stm=数字, st:数字, etm=数字, end:数字 のすべてのパターンに完全対応 ★
                const startTimeMatch = clParams.match(/stm[=:]?([0-9]+)/) || clParams.match(/st:([0-9]+)/);
                const endTimeMatch = clParams.match(/etm[=:]?([0-9]+)/) || clParams.match(/end:([0-9]+)/);

                const itemId = cidMatch ? cidMatch[1] : href.split('/auction/')[1]?.split('?')[0];
                const price = priceMatch ? parseInt(priceMatch[1], 10) : 0;

                if (!itemId || processedIds.has(itemId)) return;
                processedIds.add(itemId);

                const cardContainer = linkEl.closest('li') || linkEl.parentElement;
                const imgEl = cardContainer ? cardContainer.querySelector('img') : null;
                
                let title = imgEl && imgEl.alt ? imgEl.alt : '';
                if (!title && cardContainer) {
                    title = cardContainer.textContent.trim().split('\n')[0];
                }

                const imageUrl = getValidImageUrl(imgEl);
                const containerText = cardContainer ? cardContainer.textContent : '';
                const isFreeShipping = containerText.includes('送料無料');

                const stmSec = startTimeMatch ? parseInt(startTimeMatch[1], 10) : null;
                const etmSec = endTimeMatch ? parseInt(endTimeMatch[1], 10) : null;

                if (itemId && price > 0) {
                    items.push({
                        site: 'yahoo_auction',
                        item_id: itemId,
                        title: title.trim(),
                        price: price,
                        category_id: catMatch ? catMatch[1] : null,
                        url: href,
                        image_url: imageUrl,
                        is_shipping_included: isFreeShipping,
                        status: 'on_sale',
                        stm: stmSec,
                        etm: etmSec,
                        start_time: stmSec ? new Date(stmSec * 1000).toISOString() : null,
                        end_time: etmSec ? new Date(etmSec * 1000).toISOString() : null
                    });
                }
            });

            if (chrome.runtime?.id) {
                chrome.runtime.sendMessage({ action: 'YAHOO_AUCTION_DATA_CAPTURED', data: items }).catch(() => {});
            }
        }
    }, 500);
}