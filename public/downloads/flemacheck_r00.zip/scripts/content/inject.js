// ==========================================
// 1. サイト別アダプター設定 (将来の複数サイト対応)
// ==========================================
const siteAdapters = {
    mercari: {
        matchHost: (hostname) => hostname.includes('mercari.com') || hostname.includes('mercari.jp'),
        targetUrlIncludes: 'entities:search',
        extractItems: (data) => data.items || []
    }
    // 将来追加するサイトの例：
    // yahoo: {
    //     matchHost: (hostname) => hostname.includes('yahoo.co.jp'),
    //     targetUrlIncludes: 'api/search',
    //     extractItems: (data) => data.results || []
    // }
};

// 現在のアクセス先URLから対応するアダプターを特定
const currentSite = Object.keys(siteAdapters).find(key => siteAdapters[key].matchHost(window.location.hostname));
const adapter = currentSite ? siteAdapters[currentSite] : null;

// ==========================================
// 2. 共通通信フック処理
// ==========================================
if (adapter) {
    const sendToContent = (url, status, data) => {
        const items = adapter.extractItems(data);
        if (items.length === 0) return;

        console.log(`【Inject: ${currentSite} キャプチャ成功】:`, url);
        window.postMessage({
            source: 'FLEA_MARKET_HOOK',
            payload: {
                site: currentSite,
                url: url,
                status: status,
                isRateLimited: status === 429,
                items: items
            }
        }, '*');
    };

    // Fetch API のフック
    const originalFetch = window.fetch;
    window.fetch = async function(...args) {
        const response = await originalFetch.apply(this, args);
        const clone = response.clone();
        const url = typeof args[0] === 'string' ? args[0] : (args[0] && args[0].url ? args[0].url : '');

        if (url.includes(adapter.targetUrlIncludes)) {
            clone.json().then(data => sendToContent(url, response.status, data)).catch(() => {});
        }
        return response;
    };

    // XMLHttpRequest のフック
    const originalXHR = window.XMLHttpRequest;
    window.XMLHttpRequest = function() {
        const xhr = new originalXHR();
        let requestUrl = '';

        const originalOpen = xhr.open;
        xhr.open = function(method, url, ...args) {
            requestUrl = typeof url === 'string' ? url : url.toString();
            return originalOpen.apply(this, [method, url, ...args]);
        };

        const originalSend = xhr.send;
        xhr.send = function(body) {
            this.addEventListener('load', function() {
                if (requestUrl.includes(adapter.targetUrlIncludes)) {
                    try {
                        const data = JSON.parse(this.responseText);
                        sendToContent(requestUrl, this.status, data);
                    } catch (e) {
                        console.warn("【Inject】XHR JSONパースエラー");
                    }
                }
            });
            return originalSend.apply(this, [body]);
        };
        return xhr;
    };
}