import { formatDateStr, extractSoldDateFromItem, isNewCondition, normalizeStatus, parseDateRobust } from '../utils/formatters.js';

/**
 * 相場分析サマリ描画
 */
export function renderAnalysisSummary(analysis, elements) {
  // ★ elements に soldMedPriceEl を追加
  const { block, rankEl, soldMedPriceEl, priceEl, daysEl } = elements;
  if (!block) return;
  
  if (analysis.p_sold_med === 0 && analysis.p_active_min === 0) {
    block.style.display = 'none';
    return;
  }

  block.style.display = 'block';
  
  if (rankEl) {
    const noteText = analysis.note ? ` [${analysis.note}]` : '';
    rankEl.textContent = `${analysis.rank}${noteText}`;
    
    if (analysis.rank.startsWith('S')) rankEl.style.color = '#f5222d';
    else if (analysis.rank.startsWith('A')) rankEl.style.color = '#fa8c16';
    else if (analysis.rank.startsWith('B')) rankEl.style.color = '#52c41a';
    else rankEl.style.color = '#8c8c8c';
  }

  // ★ メルカリ相場価格 (p_sold_med) の描画を追加
  if (soldMedPriceEl) {
    soldMedPriceEl.textContent = analysis.p_sold_med > 0 
      ? `¥${analysis.p_sold_med.toLocaleString()}` 
      : 'データ不足';
  }

  if (priceEl) {
    priceEl.textContent = analysis.suggestedPrice > 0 
      ? `¥${analysis.suggestedPrice.toLocaleString()}` 
      : '算出不可';
  }

  if (daysEl) {
    daysEl.textContent = analysis.isValid && analysis.d_sold_med > 0
      ? `${analysis.d_sold_med.toFixed(1)} 日`
      : 'データ不足';
  }
}

/**
 * サイト別サマリテーブル描画
 */
export function renderSummary(items, tbodyEl) {
  if (!tbodyEl) return;

  const sites = [
    { key: 'mercari', name: 'メルカリ' },
    { key: 'rakuma', name: 'ラクマ' },
    { key: 'yflea', name: 'Yフリマ' },
    { key: 'yahoo_auction', name: 'ヤフオク' }
  ];

  tbodyEl.innerHTML = '';

  sites.forEach(s => {
    const siteItems = items.filter(i => i.site === s.key);
    const count = siteItems.length;

    let minStr = '-', maxStr = '-', avgStr = '-';

    if (count > 0) {
      const prices = siteItems.map(i => Number(i.price)).filter(p => !isNaN(p));
      if (prices.length > 0) {
        const min = Math.min(...prices);
        const max = Math.max(...prices);
        const avg = Math.round(prices.reduce((a, b) => a + b, 0) / prices.length);

        minStr = `¥${min.toLocaleString()}`;
        maxStr = `¥${max.toLocaleString()}`;
        avgStr = `¥${avg.toLocaleString()}`;
      }
    }

    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${s.name}</td>
      <td>${count}</td>
      <td>${minStr}</td>
      <td>${maxStr}</td>
      <td>${avgStr}</td>
    `;
    tbodyEl.appendChild(tr);
  });
}

/**
 * 商品カードリスト描画
 */
export function renderItemList(items, analysis, listEl) {
  if (!listEl) return;
  listEl.innerHTML = '';

  if (!items || items.length === 0) {
    listEl.innerHTML = '<div class="empty-state" style="padding: 12px; color: #666;">該当する商品が見つかりませんでした。</div>';
    return;
  }

  const siteNames = {
    mercari: 'メルカリ',
    rakuma: 'ラクマ',
    yflea: 'Yフリマ',
    yahoo_auction: 'ヤフオク'
  };
  
  const statusLabels = {
    'on_sale': '販売中',
    'sold_out': '売り切れ',
    'ended': '終了'
  };

  const NOW = Date.now();
  const LIMIT_HOURS = 24;

  items.forEach(item => {
    const card = document.createElement('div');
    card.className = 'item-card';

    const siteClass = `badge-${item.site}`;
    const siteName = siteNames[item.site] || item.site;
    const normalizedStatus = normalizeStatus(item.status);
    const statusLabel = statusLabels[normalizedStatus] || '不明';

    let highlightHtml = '';
    if (analysis && analysis.isValid && normalizedStatus === 'on_sale') {
      const p = Number(item.price);
      if (p > 0 && p < (analysis.p_sold_med * 0.8)) {
        card.classList.add('highlight-blue');
        highlightHtml = `<span style="font-size:10px; color:#1890ff; font-weight:bold; margin-left:4px;">[刈り取り!]</span>`;
      } else if (item.site === 'mercari' && analysis.rank.startsWith('S') && p > (analysis.p_sold_med * 1.1)) {
        card.classList.add('highlight-red');
        highlightHtml = `<span style="font-size:10px; color:#f5222d; font-weight:bold; margin-left:4px;">[独占・高値!]</span>`;
      } else if (item.site !== 'mercari') {
        const sDate = parseDateRobust(item.start_time);
        if (sDate) {
          const daysOld = (NOW - sDate.getTime()) / (1000 * 60 * 60 * 24);
          if (p < analysis.p_sold_med && daysOld > 14) {
            card.classList.add('highlight-yellow');
            highlightHtml = `<span style="font-size:10px; color:#faad14; font-weight:bold; margin-left:4px;">[値崩れ警戒]</span>`;
          }
        }
      }
    }

    card.setAttribute('data-status', normalizedStatus);

    const isNew = isNewCondition(item);
    const conditionBadgeHtml = isNew 
      ? `<span class="site-badge badge-condition-new">新品</span>`
      : `<span class="site-badge badge-condition-used">中古</span>`;

    let priceHtml = `<span class="item-price">¥${item.price.toLocaleString()}</span>`;
    
    if (item.prev_price && item.prev_price > item.price) {
      let isWithinLimit = false;

      if (item.price_changed_at) {
        let dateStr = String(item.price_changed_at).trim();
        if (!dateStr.includes('Z') && !dateStr.includes('+')) {
          dateStr = dateStr.replace(' ', 'T') + 'Z';
        }

        const changedTime = new Date(dateStr).getTime();
        if (!isNaN(changedTime)) {
          const hoursPassed = (NOW - changedTime) / (1000 * 60 * 60);
          isWithinLimit = hoursPassed >= 0 && hoursPassed <= LIMIT_HOURS;
        }
      }

      if (isWithinLimit) {
        const diff = item.prev_price - item.price;
        priceHtml = `
          <span class="prev-price">¥${item.prev_price.toLocaleString()}</span>
          <span class="item-price">¥${item.price.toLocaleString()}</span>
          <span class="price-down-badge">¥${diff.toLocaleString()}値下げ!</span>
        `;
      }
    }

    const startTimeFormatted = formatDateStr(item.start_time);
    const rawSoldVal = extractSoldDateFromItem(item);
    const soldTimeFormatted = formatDateStr(rawSoldVal);

    let dateInfoHtml = '';
    if (startTimeFormatted) {
      dateInfoHtml += `<span class="date-badge" title="出品日時">出品: ${startTimeFormatted}</span>`;
    }
    if ((normalizedStatus === 'sold_out' || normalizedStatus === 'ended') && soldTimeFormatted) {
      dateInfoHtml += `<span class="date-badge sold-date" title="Sold/終了日時">Sold: ${soldTimeFormatted}</span>`;
    }

    card.innerHTML = `
      <img src="${item.image_url || 'https://via.placeholder.com/60'}" alt="thumb">
      <div class="item-info">
        <p class="item-title">
          <span class="site-badge ${siteClass}">${siteName}</span>
          ${conditionBadgeHtml}
          <a href="${item.url}" target="_blank">${item.title}</a>
        </p>
        <div class="item-price-wrapper">
          ${priceHtml}
          <span class="status-badge" data-status="${normalizedStatus}">${statusLabel}</span>
          ${highlightHtml}
        </div>
        ${dateInfoHtml ? `<div class="item-date-wrapper" style="margin-top: 4px; font-size: 0.75rem; color: #666; display: flex; gap: 8px;">${dateInfoHtml}</div>` : ''}
      </div>
    `;
    listEl.appendChild(card);
  });
}