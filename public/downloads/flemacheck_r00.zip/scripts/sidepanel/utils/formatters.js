/**
 * 中央値を計算
 */
export function getMedian(arr) {
  if (!arr || arr.length === 0) return 0;
  const sorted = [...arr].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 !== 0 
    ? sorted[mid] 
    : (sorted[mid - 1] + sorted[mid]) / 2;
}

/**
 * 日時文字列を Date オブジェクトに変換
 */
export function parseDateRobust(dateVal) {
  if (!dateVal) return null;
  const strVal = String(dateVal).trim();
  if (/^\d{10,13}$/.test(strVal)) {
    const num = Number(strVal);
    return new Date(num < 10000000000 ? num * 1000 : num);
  }
  let str = strVal;
  if (!str.includes('Z') && !str.includes('+')) {
    str = str.replace(' ', 'T') + 'Z';
  }
  const d = new Date(str);
  return isNaN(d.getTime()) ? null : d;
}

/**
 * 「YYYY/MM/DD HH:mm」形式にフォーマット
 */
export function formatDateStr(dateVal) {
  const d = parseDateRobust(dateVal);
  if (!d) return null;

  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  const hh = String(d.getHours()).padStart(2, '0');
  const mi = String(d.getMinutes()).padStart(2, '0');

  return `${yyyy}/${mm}/${dd} ${hh}:${mi}`;
}

/**
 * Sold/終了日時を抽出
 */
export function extractSoldDateFromItem(item) {
  if (!item) return null;
  if (item.last_status_changed_at) return item.last_status_changed_at;
  if (item.end_time) return item.end_time;

  if (item.raw_json) {
    try {
      const raw = typeof item.raw_json === 'string' ? JSON.parse(item.raw_json) : item.raw_json;
      if (raw.updated) return raw.updated;
      if (raw.endTime) return raw.endTime;
    } catch (e) {}
  }
  return item.updated || null;
}

/**
 * 新品判定
 */
export function isNewCondition(item) {
  if (!item.raw_json) return false;
  try {
    const raw = typeof item.raw_json === 'string' ? JSON.parse(item.raw_json) : item.raw_json;
    if (item.site === 'mercari') return String(raw.itemConditionId) === '1';
    if (item.site === 'yflea') {
      const cond = raw.condition || (raw.raw_json && raw.raw_json.condition);
      if (cond && typeof cond === 'string') return cond.startsWith('new');
    }
    if (item.condition_id !== null && item.condition_id !== undefined) {
      const cid = Number(item.condition_id);
      return cid === 1 || cid === 10;
    }
  } catch (e) {
    console.error('Failed to parse raw_json for condition check:', e);
  }
  return false;
}

/**
 * ステータス正規化
 */
export function normalizeStatus(rawStatus) {
  if (!rawStatus) return 'on_sale';
  const statusStr = String(rawStatus).toUpperCase();
  
  if (['ITEM_STATUS_SOLD_OUT', 'ITEM_STATUS_TRADING', 'SOLD', 'SOLD_OUT', 'CLOSED', 'sold_out'].includes(statusStr)) {
    return 'sold_out';
  }
  if (['ITEM_STATUS_ON_SALE', 'ON_SALE', 'OPEN', 'on_sale'].includes(statusStr)) {
    return 'on_sale';
  }
  if (['ITEM_STATUS_INACTIVE', 'ITEM_STATUS_CANCELLED', 'ENDED', 'ended'].includes(statusStr)) {
    return 'ended';
  }
  return 'on_sale';
}