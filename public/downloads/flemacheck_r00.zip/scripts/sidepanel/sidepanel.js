// scripts/sidepanel/sidepanel.js

import { normalizeStatus, isNewCondition } from './utils/formatters.js';
import { calculateMarketAnalysis } from './services/marketAnalysis.js';
import { renderAnalysisSummary, renderSummary, renderItemList } from './ui/renderers.js';
// ★ 追加: API通信の代わりに、ローカルストレージ用クライアントをインポート
import { getItemsByKeyword } from '../modules/dbClient.js';

let allItems = [];
let mercariSoldItems = [];
let currentKeyword = '';

// DOM要素の保持
const listEl = document.getElementById('item-list');
const statusEl = document.getElementById('status');
const summaryTbody = document.getElementById('summary-tbody');
const filterPriceMin = document.getElementById('filter-price-min');
const filterPriceMax = document.getElementById('filter-price-max');
const filterTitleInclude = document.getElementById('filter-title-include');
const filterTitleExclude = document.getElementById('filter-title-exclude');
const applyFilterBtn = document.getElementById('apply-filter-btn');

const analysisElements = {
  block: document.getElementById('market-analysis-summary'),
  rankEl: document.getElementById('analysis-rank'),
  soldMedPriceEl: document.getElementById('analysis-sold-med-price'),
  priceEl: document.getElementById('analysis-suggested-price'),
  daysEl: document.getElementById('analysis-avg-days')
};

/**
 * データ読込 (ローカルサーバー通信を廃止し、ストレージから取得)
 */
async function loadItems(keyword) {
  if (!keyword) return;
  currentKeyword = keyword;

  if (statusEl) {
    statusEl.textContent = `「${keyword}」のデータを取得中...`;
    statusEl.style.display = 'block';
  }

  try {
    // ★ 修正: localhostへのfetchを削除し、dbClientから直接取得
    allItems = await getItemsByKeyword(keyword);

    mercariSoldItems = allItems.filter(item => 
      item.site === 'mercari' && normalizeStatus(item.status) === 'sold_out'
    );

    const activeCount = allItems.filter(i => normalizeStatus(i.status) === 'on_sale').length;
    
    if (statusEl) {
      statusEl.textContent = `「${keyword}」の検索結果 (出品中: ${activeCount}件 / メルカリSold: ${mercariSoldItems.length}件)`;
      statusEl.style.display = 'block';
    }

    applyFiltersAndRender();

  } catch (err) {
    console.error('Failed to load items:', err);
    if (statusEl) {
      statusEl.textContent = 'データの読み込みに失敗しました。';
      statusEl.style.display = 'block';
    }
  }
}

/**
 * フィルタ適用・描画パイプライン
 */
function applyFiltersAndRender() {
  if (!allItems || allItems.length === 0) {
    renderItemList([], null, listEl);
    renderSummary([], summaryTbody);
    if (analysisElements.block) analysisElements.block.style.display = 'none';
    return;
  }

  const minPrice = filterPriceMin && filterPriceMin.value !== '' ? Number(filterPriceMin.value) : 0;
  const maxPrice = filterPriceMax && filterPriceMax.value !== '' ? Number(filterPriceMax.value) : Infinity;

  const includeVal = filterTitleInclude ? filterTitleInclude.value.trim().toLowerCase() : '';
  const excludeVal = filterTitleExclude ? filterTitleExclude.value.trim().toLowerCase() : '';

  const includeWords = includeVal ? includeVal.split(/\s+/) : [];
  const excludeWords = excludeVal ? excludeVal.split(/\s+/) : [];

  const checkTitleMatch = (titleRaw) => {
    const title = (titleRaw || '').toLowerCase();
    
    if (includeWords.length > 0) {
      const hasAllIncludes = includeWords.every(word => title.includes(word));
      if (!hasAllIncludes) return false;
    }
    
    if (excludeWords.length > 0) {
      const hasAnyExcludes = excludeWords.some(word => title.includes(word));
      if (hasAnyExcludes) return false;
    }
    
    return true;
  };

  const checkedStatuses = Array.from(document.querySelectorAll('input[name="filter-status"]:checked'))
    .map(cb => cb.value);

  const conditionRadio = document.querySelector('input[name="filter-condition"]:checked');
  const selectedCondition = conditionRadio ? conditionRadio.value : 'all';

  const filteredActiveItems = allItems.filter(item => {
    const price = Number(item.price) || 0;
    const normalizedStatus = normalizeStatus(item.status);
    const matchPrice = price >= minPrice && price <= maxPrice;
    const matchStatus = checkedStatuses.length === 0 || checkedStatuses.includes(normalizedStatus);
    const matchTitle = checkTitleMatch(item.title);

    let matchCondition = true;
    if (selectedCondition !== 'all') {
      const isNew = isNewCondition(item);
      if (selectedCondition === 'new' && !isNew) matchCondition = false;
      if (selectedCondition === 'used' && isNew) matchCondition = false;
    }
    return matchPrice && matchStatus && matchCondition && matchTitle;
  });

  const filteredSoldItems = mercariSoldItems.filter(item => {
    const price = Number(item.price) || 0;
    const matchPrice = price >= minPrice && price <= maxPrice;
    const matchTitle = checkTitleMatch(item.title);

    let matchCondition = true;
    if (selectedCondition !== 'all') {
      const isNew = isNewCondition(item);
      if (selectedCondition === 'new' && !isNew) matchCondition = false;
      if (selectedCondition === 'used' && isNew) matchCondition = false;
    }
    return matchPrice && matchCondition && matchTitle;
  });

  const analysisResult = calculateMarketAnalysis(filteredActiveItems, filteredSoldItems);
  
  renderAnalysisSummary(analysisResult, analysisElements);
  renderSummary(filteredActiveItems, summaryTbody);
  renderItemList(filteredActiveItems, analysisResult, listEl);
}

// イベントリスナー設定
if (applyFilterBtn) {
  applyFilterBtn.addEventListener('click', applyFiltersAndRender);
}

document.querySelectorAll('input[name="filter-condition"]').forEach(radio => {
  radio.addEventListener('change', applyFiltersAndRender);
});

chrome.runtime.onMessage.addListener((message) => {
  if (message.action === 'DB_UPDATED' && message.keyword) {
    loadItems(message.keyword);
  }
});

document.addEventListener('DOMContentLoaded', async () => {
  try {
    let lastKeyword = '';
    if (chrome?.storage?.local) {
      const res = await chrome.storage.local.get(['lastKeyword']);
      lastKeyword = res?.lastKeyword || '';
    } else {
      lastKeyword = localStorage.getItem('lastKeyword') || '';
    }

    if (lastKeyword) loadItems(lastKeyword);
  } catch (e) {
    console.error('Failed to restore last keyword:', e);
  }
});