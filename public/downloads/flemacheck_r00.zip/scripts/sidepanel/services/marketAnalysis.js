import { getMedian, parseDateRobust, extractSoldDateFromItem, normalizeStatus } from '../utils/formatters.js';

/**
 * 相場分析・判定・計算ロジック（メルカリ最安値基準 ＋ 直近90日優先＋段階的フォールバック）
 */
export function calculateMarketAnalysis(activeItems, soldItems) {
  const nowMs = Date.now();
  const MS_IN_DAY = 1000 * 60 * 60 * 24;
  const RECENT_DAYS = 90;

  let result = {
    isValid: false,
    p_sold_med: 0,   // ★ メルカリ相場価格（この値をUI描画で使用します）
    d_sold_med: 0,   // 過去の平均販売日数
    p_active_min: 0, // ★メルカリ内の現在最安値（ライバルの底値）
    d_active_med: 0,
    rank: '-',       // 売り時ランク
    suggestedPrice: 0, // 推奨販売価格
    note: ''         // 直近相場などのタグ
  };

  // --- 1. メルカリの Active（出品中）データの指標計算 ---
  // ★変更点: 全サイトではなく「メルカリ」の出品中データのみから最安値・停滞度を抽出
  const mercariOnSaleItems = activeItems.filter(i => 
    i.site === 'mercari' && normalizeStatus(i.status) === 'on_sale'
  );
  
  const mercariActivePrices = mercariOnSaleItems.map(i => Number(i.price)).filter(p => p > 0);
  result.p_active_min = mercariActivePrices.length > 0 ? Math.min(...mercariActivePrices) : 0;

  const mercariActiveDays = mercariOnSaleItems.map(i => {
    const startD = parseDateRobust(i.start_time);
    return startD ? (nowMs - startD.getTime()) / MS_IN_DAY : null;
  }).filter(d => d !== null);
  result.d_active_med = mercariActiveDays.length > 0 ? getMedian(mercariActiveDays) : 0;

  // --- 2. 全期間 Sold が 0 件の場合のフェイルセーフ ---
  if (soldItems.length === 0) {
    result.isValid = false;
    result.rank = '判定不可 (実績ゼロ)';
    // メルカリ最安値があればその90%を仮提示
    result.suggestedPrice = result.p_active_min > 0 ? Math.floor(result.p_active_min * 0.9) : 0;
    return result;
  }

  // --- 3. Sold データを「直近90日以内」と「それ以前」に分離 ---
  const recentSoldItems = soldItems.filter(i => {
    const soldDateRaw = extractSoldDateFromItem(i);
    const soldD = parseDateRobust(soldDateRaw);
    if (!soldD) return false;
    const daysAgo = (nowMs - soldD.getTime()) / MS_IN_DAY;
    return daysAgo >= 0 && daysAgo <= RECENT_DAYS;
  });

  let targetSoldItems = [];
  let isRecentData = false;

  if (recentSoldItems.length >= 3) {
    targetSoldItems = recentSoldItems;
    isRecentData = true;
    result.note = '直近3ヶ月相場';
  } else if (recentSoldItems.length > 0) {
    targetSoldItems = recentSoldItems;
    isRecentData = true;
    result.note = '直近取引僅少';
  } else {
    targetSoldItems = soldItems;
    isRecentData = false;
    result.note = '直近3ヶ月取引なし';
  }

  // --- 4. 基礎指標の計算（メルカリ相場中央値・平均販売スピード） ---
  const soldPrices = targetSoldItems.map(i => Number(i.price)).filter(p => p > 0);
  result.p_sold_med = getMedian(soldPrices); // ★ ここで算出された相場価格をUIに渡します

  const soldSpeedDays = targetSoldItems.map(i => {
    const startD = parseDateRobust(i.start_time);
    const endRaw = extractSoldDateFromItem(i);
    const endD = parseDateRobust(endRaw);
    if (startD && endD) {
      const diffDays = (endD.getTime() - startD.getTime()) / MS_IN_DAY;
      return diffDays >= 0 ? diffDays : null;
    }
    return null;
  }).filter(d => d !== null);
  result.d_sold_med = soldSpeedDays.length > 0 ? getMedian(soldSpeedDays) : 0;

  result.isValid = true;

  // --- 5. 売り時ランク判定 & 直近実績なしペナルティ ---
  if (!isRecentData) {
    result.rank = 'C (需要低下・直近実績なし)';
  } else {
    if (result.d_sold_med <= 3) result.rank = 'S (即売れ警戒・高需要)';
    else if (result.d_sold_med <= 7) result.rank = 'A (売り時・需要あり)';
    else if (result.d_sold_med <= 14) result.rank = 'B (普通・適正価格なら売れる)';
    else result.rank = 'C (停滞・値下げ検討)';
  }

  // --- 6. 推奨販売価格の算出 (メルカリ最安値との比較) ---
  // メルカリ内に自分より安いライバル(最安値)がいる場合、相場中央値とライバル最安値の中間値を狙う
  if (result.p_active_min > 0 && result.p_active_min < result.p_sold_med) {
    result.suggestedPrice = Math.floor((result.p_sold_med + result.p_active_min) / 2);
  } else {
    // メルカリ内にライバルがいない、またはライバル最安値が相場以上の場合は相場価格通りに設定
    result.suggestedPrice = result.p_sold_med;
  }

  // 直近取引がない場合は売り切りのため推奨価格を10%下げる
  if (!isRecentData && result.suggestedPrice > 0) {
    result.suggestedPrice = Math.floor(result.suggestedPrice * 0.9);
  }

  return result;
}