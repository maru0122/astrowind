// scripts/modules/dbClient.js
// 【スタンドアロン / GitHub公開版】
// 外部サーバー（SQLite）を使わず、ブラウザ内ストレージ（chrome.storage.local）で完全互換動作します。
// 容量オーバーを防ぐため、最新1,000件の自動ローテーションと軽量化を実施しています。

const MAX_STORAGE_ITEMS = 1000;

/**
 * 取得・正規化した商品データをブラウザ内ストレージへ一括保存・更新 (UPSERT)
 * ※ SQLiteサーバー側で行っていた `prev_price` や `last_status_changed_at` の差分判定を完全再現します。
 * @param {Array<Object>} items - 正規化された商品オブジェクトの配列
 * @returns {Promise<{success: boolean, count?: number, error?: string}>}
 */
export async function saveItemsToDb(items) {
  if (!items || items.length === 0) return { success: true, count: 0 };

  try {
    // 1. 既存データをストレージから取得
    const data = await chrome.storage.local.get(['items']);
    const existingItems = data.items || [];

    // 高速照合のため (site + item_id) をキーにしたMapを作成
    const itemMap = new Map();
    for (const item of existingItems) {
      itemMap.set(`${item.site}_${item.item_id}`, item);
    }

    const nowIso = new Date().toISOString();

    // 2. 差分判定とUPSERT実行
    for (const newItem of items) {
      const key = `${newItem.site}_${newItem.item_id}`;

      // 【容量節約】巨大な生JSONや説明文を除外し、1件あたり0.3KB〜0.5KB程度に圧縮
      const cleanItem = { ...newItem };
      delete cleanItem.raw_json;
      delete cleanItem.description;

      if (itemMap.has(key)) {
        const prev = itemMap.get(key);

        // 価格変更の検知 (SQLiteの price_changed_at / prev_price 相当)
        if (prev.price && cleanItem.price && prev.price !== cleanItem.price) {
          cleanItem.prev_price = prev.price;
          cleanItem.price_changed_at = nowIso;
        } else {
          cleanItem.prev_price = prev.prev_price;
          cleanItem.price_changed_at = prev.price_changed_at;
        }

        // ステータス変更の検知 (last_status_changed_at 相当)
        if (prev.status && cleanItem.status && prev.status !== cleanItem.status) {
          cleanItem.last_status_changed_at = nowIso;
        } else {
          cleanItem.last_status_changed_at = prev.last_status_changed_at;
        }

        // 既存の値を保持しながら更新
        itemMap.set(key, {
          ...prev,
          ...cleanItem,
          updated_at: nowIso
        });
      } else {
        // 新規登録
        cleanItem.created_at = cleanItem.created_at || nowIso;
        cleanItem.updated_at = nowIso;
        itemMap.set(key, cleanItem);
      }
    }

    // 3. 最新1,000件に制限（更新日時が新しい順にソートして切り詰め）
    let updatedList = Array.from(itemMap.values());
    if (updatedList.length > MAX_STORAGE_ITEMS) {
      updatedList.sort((a, b) => new Date(b.updated_at || 0) - new Date(a.updated_at || 0));
      updatedList = updatedList.slice(0, MAX_STORAGE_ITEMS);
    }

    // 4. 保存
    await chrome.storage.local.set({ items: updatedList });

    return { success: true, count: items.length };
  } catch (error) {
    console.error('❌ [dbClient] ストレージ保存エラー:', error);
    return { success: false, error: error.message };
  }
}

/**
 * 検索キーワードにマッチする商品一覧をストレージから取得（最安値順）
 * ※ レスポンスオブジェクトには `prev_price` や `last_status_changed_at` が含まれます。
 * @param {string} keyword - 検索キーワード
 * @returns {Promise<Array<Object>>}
 */
export async function getItemsByKeyword(keyword) {
  if (!keyword) return [];

  try {
    const data = await chrome.storage.local.get(['items']);
    const items = data.items || [];
    const targetKeyword = keyword.trim().toLowerCase();

    // キーワード合致判定（完全一致または部分一致）
    const filtered = items.filter(item => {
      if (!item.keyword) return false;
      const k = item.keyword.trim().toLowerCase();
      return k === targetKeyword || k.includes(targetKeyword) || targetKeyword.includes(k);
    });

    // SQLiteの「ORDER BY price ASC」を再現（最安値順）
    filtered.sort((a, b) => (Number(a.price) || 0) - (Number(b.price) || 0));

    return filtered;
  } catch (error) {
    console.error('❌ [dbClient] ストレージ取得エラー:', error);
    return [];
  }
}

/**
 * 相場分析用にメルカリのSold（実績）データのみを取得
 * @param {string} keyword - 検索キーワード
 * @returns {Promise<Array<Object>>}
 */
export async function getMercariSoldItems(keyword) {
  if (!keyword) return [];

  try {
    // まずキーワードで絞り込んだアイテムを取得
    const items = await getItemsByKeyword(keyword);

    // メルカリ かつ Soldステータスの商品のみ抽出
    return items.filter(item => {
      const isMercari = item.site === 'mercari';
      const isSold = item.status === 'sold_out' || item.status === 'ended';
      return isMercari && isSold;
    });
  } catch (error) {
    console.error('❌ [dbClient] メルカリSoldデータ取得エラー:', error);
    return [];
  }
}