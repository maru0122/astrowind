/**
 * 汎用の裏タブ検索関数
 */
function fetchByTab(searchUrl, actionName, timeoutMs = 12000) {
  return new Promise((resolve, reject) => {
    let targetTabId = null;

    const timer = setTimeout(() => {
      cleanup();
      if (targetTabId) chrome.tabs.remove(targetTabId);
      reject(new Error(`${actionName} のデータ取得がタイムアウトしました`));
    }, timeoutMs);

    const messageListener = (message, sender) => {
      if (sender.tab && sender.tab.id === targetTabId && message.action === actionName) {
        cleanup();
        chrome.tabs.remove(targetTabId);
        resolve(message.data || []);
      }
    };

    function cleanup() {
      clearTimeout(timer);
      chrome.runtime.onMessage.removeListener(messageListener);
    }

    chrome.runtime.onMessage.addListener(messageListener);

    chrome.tabs.create({ url: searchUrl, active: false }, (tab) => {
      if (chrome.runtime.lastError) {
        cleanup();
        reject(chrome.runtime.lastError);
        return;
      }
      targetTabId = tab.id;
    });
  });
}

// ラクマ
export function fetchRakumaByTab(keyword) {
  const url = `https://fril.jp/s?query=${encodeURIComponent(keyword)}&transaction=selling`;
  return fetchByTab(url, 'RAKUMA_DATA_CAPTURED');
}

// Yフリマ (PayPayフリマ)
export function fetchYFleaByTab(keyword) {
  const url = `https://paypayfleamarket.yahoo.co.jp/search/${encodeURIComponent(keyword)}`;
  return fetchByTab(url, 'YFLEA_DATA_CAPTURED');
}

// ヤフオク (即決・販売中のみ)
export function fetchYahooAuctionByTab(keyword) {
  const url = `https://auctions.yahoo.co.jp/search/search?p=${encodeURIComponent(keyword)}&va=${encodeURIComponent(keyword)}&is_postage_mode=1&dest_pref_code=13&exflg=1&b=1&n=50&mode=1`;
  return fetchByTab(url, 'YAHOO_AUCTION_DATA_CAPTURED');
}