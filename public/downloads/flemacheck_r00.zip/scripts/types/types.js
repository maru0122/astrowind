/**
 * フリマサイトごとのアダプター設定
 * @typedef {Object} SiteAdapter
 * @property {function(string): boolean} matchHost - 現在のホスト名が対象サイトか判定する
 * @property {string} targetUrlIncludes - フック対象となるAPIのURLに含まれる文字列
 * @property {function(Object): Object[]} extractItems - APIレスポンスからアイテム配列を抽出するロジック
 */

/**
 * Backgroundへ送信される整形済みペイロード
 * @typedef {Object} InterceptPayload
 * @property {string} site - サイト識別子 (例: 'mercari')
 * @property {string} url - キャプチャしたAPIのURL
 * @property {number} status - HTTPステータス
 * @property {boolean} isRateLimited - 429エラーかどうか
 * @property {Object[]} items - 抽出されたアイテムデータの配列
 */